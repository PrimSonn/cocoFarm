package cocoFarm.util.recptMaker;

public interface Serializer {
	public String doSerialize();
}