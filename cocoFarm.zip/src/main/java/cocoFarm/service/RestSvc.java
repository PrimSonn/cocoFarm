package cocoFarm.service;


public interface RestSvc {

	public Integer checkPayment(String mercUid, Integer accIdx);
}
