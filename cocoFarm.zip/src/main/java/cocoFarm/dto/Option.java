package cocoFarm.dto;

import java.util.List;

public class Option {
	private List<SaleOption> saleOptions;

	public List<SaleOption> getSaleOptions() {
		return saleOptions;
	}

	public void setSaleOptions(List<SaleOption> saleOptions) {
		this.saleOptions = saleOptions;
	}
}
