package cocoFarm.dto;

public class CheckerDto {

	private Integer isDone;

	public Integer getIsDone() {
		return isDone;
	}

	public void setIsDone(Integer isDone) {
		this.isDone = isDone;
	}
}
