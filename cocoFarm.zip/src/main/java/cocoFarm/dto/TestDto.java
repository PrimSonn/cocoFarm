package cocoFarm.dto;

public class TestDto {//helloWorld.jsp 실험용

	private String attr;
	private Integer isDone;

	public String getAttr() {
		return attr;
	}public void setAttr(String attr) {
		this.attr = attr;
	}public Integer getIsDone() {
		return isDone;
	}public void setIsDone(Integer isDone) {
		this.isDone = isDone;
	}
}
