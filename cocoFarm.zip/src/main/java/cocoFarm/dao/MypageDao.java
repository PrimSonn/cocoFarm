package cocoFarm.dao;

public interface MypageDao {

}
